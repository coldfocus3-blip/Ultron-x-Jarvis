# JARVIS v1.4 — HOLO CORE

A tablet-first Android JARVIS foundation with a cinematic, interactive holographic core.

## Visual controls
- Drag one finger across the reactor to rotate its holographic projection through a full 360°.
- Drag vertically to tilt the projection.
- Pinch with two fingers to zoom from 0.65x to 1.8x.
- Tap the reactor to start voice recognition.
- Theme toggles between JARVIS blue and ULTRON gold.

## Voice architecture
- Android VoiceInteractionService is the global assistant entry point.
- Android keeps the selected VoiceInteractionService running for assistant/hotword support.
- The assistant session is shown by the system when the assistant is invoked.
- A user-enabled microphone foreground service provides a fallback wake-phrase loop where the device permits it.
- On-device SpeechRecognizer is preferred when available.
- JARVIS stops recognition while speaking to avoid hearing its own TTS output.

## Important Android limitation
A normal SpeechRecognizer is not a hardware hotword detector and Android documents that it is not intended for continuous recognition. True hands-free hotwording depends on the device/OEM VoiceInteractionService and hotword implementation. Selecting JARVIS as the system assistant is therefore required for the strongest supported background-assistant path.

## Command brain (JarvisBrain)
All recognized speech — from the in-app tap-to-talk button and from the
always-listening wake-phrase service — is routed through `JarvisBrain`, a
single local, dependency-free command processor. No network calls, no
third-party libraries, fully auditable. It currently understands:

- **Notes** — "note that pick up the dry cleaning", "read my notes", "clear my notes"
- **Reminders** — "remind me to check the oven in 10 minutes" (delivered as a notification)
- **Alarms & timers** — "set an alarm for 7 am", "set a timer for 20 minutes" (opens the system Clock app, pre-filled)
- **Calendar** — "schedule dentist appointment" (opens Calendar with the title pre-filled)
- **Math** — "what is 42 times 7"
- **Time / date / battery** — "what time is it", "what's the date", "battery level"
- **Navigation & calling** — "navigate to the airport", "call mum" (opens Maps/Dialer for confirmation — JARVIS never dials or navigates without you confirming)
- **Device controls** — flashlight on/off, volume up/down/mute
- **Apps & web** — "open spotify", "search for the tallest mountain", "open settings", "open calculator"

Everything runs on-device; nothing here requires an API key or sends data
anywhere. Extend it by adding a new branch to `JarvisBrain.process(...)`.

## Accessibility
The HUD is entirely hand-drawn on a `Canvas`, so it carries its own
TalkBack support: the reactor has a content description and responds to
double-tap activation (`performClick`), and every spoken response, listening
state, and theme change is pushed to screen readers via
`announceForAccessibility`.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`
Uses Java 17, Gradle 8.11.1, AGP 8.10.1, compileSdk 36.

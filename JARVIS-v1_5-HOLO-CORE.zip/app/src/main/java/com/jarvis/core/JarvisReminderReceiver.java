package com.jarvis.core;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Fires when a "remind me to ..." reminder set via JarvisBrain comes due.
 * Purely local: no network access, just a scheduled notification.
 */
public class JarvisReminderReceiver extends BroadcastReceiver {
    public static final String EXTRA_TEXT = "jarvis_reminder_text";
    private static final String CHANNEL_ID = "jarvis_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String text = intent.getStringExtra(EXTRA_TEXT);
        if (text == null || text.isEmpty()) text = "your reminder";

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "JARVIS Reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Reminders you asked JARVIS to set");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }

        Intent launch = new Intent(context, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context, text.hashCode(), launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("JARVIS reminder")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setPriority(Notification.PRIORITY_HIGH)
                .build();

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(text.hashCode(), notification);
    }
}

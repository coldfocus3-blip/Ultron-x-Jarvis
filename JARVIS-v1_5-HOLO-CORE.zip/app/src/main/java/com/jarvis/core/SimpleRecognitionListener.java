package com.jarvis.core;

import android.os.Bundle;
import android.speech.RecognitionListener;

public abstract class SimpleRecognitionListener implements RecognitionListener {
    public void onReadyForSpeech(Bundle p) {}
    public void onBeginningOfSpeech() {}
    public void onRmsChanged(float r) {}
    public void onBufferReceived(byte[] b) {}
    public void onEndOfSpeech() {}
    public void onError(int e) {}
    public void onResults(Bundle r) {}
    public void onPartialResults(Bundle r) {}
    public void onEvent(int t, Bundle p) {}
}

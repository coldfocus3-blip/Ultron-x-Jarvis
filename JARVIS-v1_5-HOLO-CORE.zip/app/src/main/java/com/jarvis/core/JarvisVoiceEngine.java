package com.jarvis.core;

import android.media.AudioAttributes;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;

import java.util.Locale;

/**
 * Central JARVIS voice profile.
 *
 * This intentionally does not clone or reproduce a specific actor's voice.
 * It selects a deeper, slower, composed English voice when the installed
 * Android TTS engine exposes one, then applies a restrained cinematic profile.
 */
public final class JarvisVoiceEngine {

    private JarvisVoiceEngine() {}

    public static void configure(TextToSpeech tts) {
        if (tts == null) return;

        // British English gives the assistant a more formal, composed character
        // than simply inheriting the device's default locale.
        try {
            tts.setLanguage(Locale.UK);
        } catch (Exception ignored) {
            try {
                tts.setLanguage(Locale.ENGLISH);
            } catch (Exception ignoredAgain) {
            }
        }

        // Cinematic male-presenting profile: slightly deeper and slower,
        // while keeping speech intelligible on small tablet speakers.
        tts.setSpeechRate(0.80f);
        tts.setPitch(0.72f);

        if (Build.VERSION.SDK_INT >= 21) {
            try {
                AudioAttributes attributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build();
                tts.setAudioAttributes(attributes);
            } catch (Exception ignored) {
            }
        }

        // Some TTS engines expose explicitly labelled male voices. Prefer one
        // in British English; otherwise choose the best British English voice.
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Voice best = null;
                Voice britishFallback = null;
                String bestName = null;

                for (Voice voice : tts.getVoices()) {
                    if (voice == null || voice.getLocale() == null) continue;
                    Locale locale = voice.getLocale();
                    if (!"en".equalsIgnoreCase(locale.getLanguage())) continue;

                    String country = locale.getCountry();
                    String name = voice.getName() == null ? "" : voice.getName();
                    String lower = name.toLowerCase(Locale.ROOT);

                    if ("GB".equalsIgnoreCase(country)) {
                        if (britishFallback == null) britishFallback = voice;
                        if (lower.contains("male") || lower.contains("man")) {
                            best = voice;
                            bestName = name;
                            break;
                        }
                    }
                }

                if (best == null) best = britishFallback;
                if (best != null) {
                    tts.setVoice(best);
                }
            } catch (Exception ignored) {
                // The TTS engine may expose no selectable voices; pitch/rate still apply.
            }
        }
    }
}

package com.jarvis.core;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * JARVIS command brain: turns recognized speech into either a spoken reply,
 * a system action (intent), or both. Kept as plain, auditable Java with no
 * network calls and no third-party dependencies -- every capability here is
 * local to the device.
 */
public final class JarvisBrain {

    private JarvisBrain() {}

    public static final class Result {
        public final String speech;
        public final Intent intent;
        public final boolean stopListening;

        private Result(String speech, Intent intent, boolean stopListening) {
            this.speech = speech;
            this.intent = intent;
            this.stopListening = stopListening;
        }

        static Result say(String speech) { return new Result(speech, null, false); }
        static Result act(String speech, Intent intent) { return new Result(speech, intent, false); }
        static Result stop(String speech) { return new Result(speech, null, true); }
    }

    private static final Map<String, String> APP_PACKAGES = new LinkedHashMap<>();
    static {
        APP_PACKAGES.put("maps", "com.google.android.apps.maps");
        APP_PACKAGES.put("gmail", "com.google.android.gm");
        APP_PACKAGES.put("email", "com.google.android.gm");
        APP_PACKAGES.put("youtube", "com.google.android.youtube");
        APP_PACKAGES.put("chrome", "com.android.chrome");
        APP_PACKAGES.put("browser", "com.android.chrome");
        APP_PACKAGES.put("spotify", "com.spotify.music");
        APP_PACKAGES.put("whatsapp", "com.whatsapp");
        APP_PACKAGES.put("photos", "com.google.android.apps.photos");
        APP_PACKAGES.put("camera", "com.android.camera2");
        APP_PACKAGES.put("calendar", "com.google.android.calendar");
        APP_PACKAGES.put("messages", "com.google.android.apps.messaging");
        APP_PACKAGES.put("phone", "com.google.android.dialer");
    }

    public static Result process(Context ctx, String rawInput) {
        String raw = rawInput == null ? "" : rawInput.trim();
        String q = raw.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return Result.say("I didn't catch that.");

        // --- Conversation control -------------------------------------------------
        if (q.equals("stop") || q.equals("cancel") || q.contains("never mind") || q.equals("nothing")) {
            return Result.stop("Standing by.");
        }
        if (q.contains("hello jarvis") || q.equals("jarvis") || q.contains("hi jarvis") || q.contains("hey jarvis")) {
            return Result.say("Online. Systems nominal. How may I assist?");
        }
        if (q.contains("who are you") || q.contains("what are you")) {
            return Result.say("I am JARVIS, your local on-device assistant, built to help with reminders, notes, quick answers, and control of this tablet.");
        }
        if (q.contains("thank")) {
            return Result.say("Always a pleasure.");
        }

        // --- Time / date / battery -------------------------------------------------
        if (q.contains("what time") || q.equals("time") || q.contains("current time")) {
            String time = new java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(new java.util.Date());
            return Result.say("The current time is " + time + ".");
        }
        if (q.contains("date") || q.contains("what day")) {
            String date = new java.text.SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(new java.util.Date());
            return Result.say("Today is " + date + ".");
        }
        if (q.contains("battery")) {
            int pct = batteryPercent(ctx);
            if (pct < 0) return Result.say("I could not read the battery level.");
            String note = pct <= 20 ? " I recommend connecting a charger soon." : "";
            return Result.say("Battery is at " + pct + " percent." + note);
        }

        // --- Math --------------------------------------------------------------
        Double mathResult = tryEvaluateMath(q);
        if (mathResult != null) {
            String formatted = (mathResult == Math.floor(mathResult) && !mathResult.isInfinite())
                    ? String.valueOf(mathResult.longValue())
                    : String.valueOf(mathResult);
            return Result.say("That comes to " + formatted + ".");
        }

        // --- Notes ---------------------------------------------------------------
        Result notes = handleNotes(ctx, q, raw);
        if (notes != null) return notes;

        // --- Reminders -------------------------------------------------------------
        Result reminder = handleReminder(ctx, q, raw);
        if (reminder != null) return reminder;

        // --- Alarms & timers (delegated to the system Clock app; no extra permission) --
        if (q.contains("alarm")) {
            int[] hm = extractTime(q);
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            if (hm != null) {
                i.putExtra(AlarmClock.EXTRA_HOUR, hm[0]);
                i.putExtra(AlarmClock.EXTRA_MINUTES, hm[1]);
                i.putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm");
                if (safeToLaunch(ctx, i)) return Result.act(String.format(Locale.US, "Setting an alarm for %02d:%02d.", hm[0], hm[1]), i);
            }
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            if (safeToLaunch(ctx, i)) return Result.act("Opening the alarm clock for you.", i);
        }
        if (q.contains("timer")) {
            int seconds = extractDurationSeconds(q);
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            if (seconds > 0) i.putExtra(AlarmClock.EXTRA_LENGTH, seconds);
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS timer");
            if (safeToLaunch(ctx, i)) {
                return Result.act(seconds > 0 ? "Timer set for " + describeDuration(seconds) + "." : "Opening the timer.", i);
            }
        }

        // --- Calendar event ---------------------------------------------------------
        if (q.startsWith("schedule") || q.startsWith("add event") || q.contains("add to my calendar")) {
            Intent i = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI);
            String title = raw.replaceFirst("(?i)^(schedule|add event|add to my calendar)\\s*", "").trim();
            if (!title.isEmpty()) i.putExtra(CalendarContract.Events.TITLE, title);
            if (safeToLaunch(ctx, i)) return Result.act("Opening your calendar to add that event.", i);
        }

        // --- Device controls --------------------------------------------------------
        if (q.contains("flashlight") || q.contains("torch")) {
            boolean on = !(q.contains("off") || q.contains("disable") || q.contains("turn off"));
            boolean ok = setFlashlight(ctx, on);
            return Result.say(ok ? ("Flashlight " + (on ? "on" : "off") + ".") : "I could not reach the flashlight on this device.");
        }
        if (q.contains("volume up") || q.contains("louder")) {
            adjustVolume(ctx, AudioManager.ADJUST_RAISE);
            return Result.say("Raising the volume.");
        }
        if (q.contains("volume down") || q.contains("quieter") || q.contains("lower the volume")) {
            adjustVolume(ctx, AudioManager.ADJUST_LOWER);
            return Result.say("Lowering the volume.");
        }
        if (q.contains("mute")) {
            adjustVolume(ctx, AudioManager.ADJUST_MUTE);
            return Result.say("Muted.");
        }

        // --- Navigation / calling --------------------------------------------------
        if (q.startsWith("navigate to") || q.startsWith("directions to") || q.startsWith("take me to")) {
            String dest = raw.replaceFirst("(?i)^(navigate to|directions to|take me to)\\s*", "").trim();
            if (!dest.isEmpty()) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)));
                if (safeToLaunch(ctx, i)) return Result.act("Charting a course to " + dest + ".", i);
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(dest)));
                return Result.act("Opening directions to " + dest + ".", web);
            }
        }
        if (q.startsWith("call ") || q.startsWith("dial ")) {
            String who = raw.replaceFirst("(?i)^(call|dial)\\s*", "").trim();
            if (!who.isEmpty()) {
                Intent i = who.matches("[0-9 +()-]+")
                        ? new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + who))
                        : new Intent(Intent.ACTION_DIAL);
                return Result.act("Opening the dialer for " + who + ". Confirm to place the call.", i);
            }
        }

        // --- Open apps ---------------------------------------------------------------
        if (q.contains("calculator")) {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR);
            if (safeToLaunch(ctx, i)) return Result.act("Opening calculator.", i);
        }
        if (q.contains("settings")) {
            return Result.act("Opening Android settings. You remain in control of system changes.",
                    new Intent(android.provider.Settings.ACTION_SETTINGS));
        }
        if (q.startsWith("open ") || q.startsWith("launch ")) {
            String name = q.replaceFirst("^(open|launch)\\s+", "").trim();
            for (Map.Entry<String, String> e : APP_PACKAGES.entrySet()) {
                if (name.contains(e.getKey())) {
                    Intent i = ctx.getPackageManager().getLaunchIntentForPackage(e.getValue());
                    if (i != null) return Result.act("Opening " + e.getKey() + ".", i);
                    return Result.say("It looks like " + e.getKey() + " is not installed on this device.");
                }
            }
        }

        // --- Web fallback for factual / lookup style questions ------------------------
        if (q.startsWith("search for") || q.startsWith("look up") || q.startsWith("who is")
                || q.startsWith("what is") || q.startsWith("what's") || q.startsWith("google")) {
            String term = raw.replaceFirst("(?i)^(search for|look up|who is|what is|what's|google)\\s*", "").trim();
            if (!term.isEmpty()) {
                Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
                i.putExtra(android.app.SearchManager.QUERY, term);
                if (safeToLaunch(ctx, i)) return Result.act("Searching for " + term + ".", i);
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(term)));
                return Result.act("Searching for " + term + ".", web);
            }
        }

        return Result.say("I heard: " + raw + ". I don't have a local command for that yet, but you can ask me for the time, battery, notes, reminders, alarms, timers, directions, or to open an app.");
    }

    // ---------------------------------------------------------------- Notes ----

    private static final String PREFS = "jarvis";
    private static final String KEY_NOTES = "notes_list";

    private static Result handleNotes(Context ctx, String q, String raw) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (q.startsWith("note that") || q.startsWith("remember that") || q.startsWith("add a note") || q.startsWith("make a note")) {
            String note = raw.replaceFirst("(?i)^(note that|remember that|add a note that|add a note|make a note that|make a note)\\s*", "").trim();
            if (note.isEmpty()) return Result.say("What would you like me to note?");
            List<String> list = loadNotes(prefs);
            list.add(note);
            saveNotes(prefs, list);
            return Result.say("Noted: " + note);
        }
        if (q.contains("read my notes") || q.contains("what are my notes") || q.contains("what did i note") || q.equals("notes")) {
            List<String> list = loadNotes(prefs);
            if (list.isEmpty()) return Result.say("You have no saved notes.");
            StringBuilder sb = new StringBuilder("You have " + list.size() + " note" + (list.size() == 1 ? "" : "s") + ": ");
            for (int i = 0; i < list.size(); i++) sb.append(i + 1).append(") ").append(list.get(i)).append(".  ");
            return Result.say(sb.toString().trim());
        }
        if (q.contains("clear my notes") || q.contains("delete my notes") || q.contains("clear notes")) {
            saveNotes(prefs, new ArrayList<>());
            return Result.say("All notes cleared.");
        }
        return null;
    }

    private static List<String> loadNotes(SharedPreferences prefs) {
        String stored = prefs.getString(KEY_NOTES, "");
        List<String> list = new ArrayList<>();
        if (!TextUtils.isEmpty(stored)) {
            for (String part : stored.split("\u0001")) if (!part.isEmpty()) list.add(part);
        }
        return list;
    }

    private static void saveNotes(SharedPreferences prefs, List<String> list) {
        prefs.edit().putString(KEY_NOTES, TextUtils.join("\u0001", list)).apply();
    }

    // ------------------------------------------------------------ Reminders ----

    private static Result handleReminder(Context ctx, String q, String raw) {
        if (!q.startsWith("remind me")) return null;
        // "remind me to <task> in <N> minutes/hours" or "... at <time>"
        String body = raw.replaceFirst("(?i)^remind me( to)?\\s*", "").trim();

        Matcher inMatch = Pattern.compile("(?i)\\bin\\s+(.+)$").matcher(body);
        int seconds = -1;
        String task = body;
        if (inMatch.find()) {
            seconds = extractDurationSeconds(inMatch.group(1));
            task = body.substring(0, inMatch.start()).trim();
        }

        if (seconds <= 0) {
            return Result.say("Tell me when: for example, \"remind me to check the oven in 10 minutes.\"");
        }
        if (task.isEmpty()) task = "your reminder";

        long triggerAt = System.currentTimeMillis() + (seconds * 1000L);
        Intent receiverIntent = new Intent(ctx, JarvisReminderReceiver.class);
        receiverIntent.putExtra(JarvisReminderReceiver.EXTRA_TEXT, task);
        int requestCode = (int) (triggerAt % Integer.MAX_VALUE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, requestCode, receiverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
        return Result.say("I will remind you to " + task + " in " + describeDuration(seconds) + ".");
    }

    // ---------------------------------------------------------------- Math -----

    private static Double tryEvaluateMath(String q) {
        String cleaned = q;
        boolean asksForMath = cleaned.contains("what is") || cleaned.contains("calculate") || cleaned.contains("what's");
        cleaned = cleaned.replaceFirst("^(what is|what's|calculate)\\s*", "");
        cleaned = cleaned.replace("plus", "+").replace("minus", "-")
                .replace("times", "*").replace("multiplied by", "*")
                .replace("divided by", "/").replace("x ", "* ")
                .replaceAll("[^0-9+\\-*/.() ]", "");
        cleaned = cleaned.trim();
        if (cleaned.isEmpty() || !cleaned.matches(".*[0-9].*") || !cleaned.matches(".*[+\\-*/].*")) {
            return null;
        }
        if (!asksForMath && !cleaned.matches("[0-9+\\-*/.() ]+")) return null;
        try {
            return new SimpleExpressionParser(cleaned).parse();
        } catch (Exception e) {
            return null;
        }
    }

    /** Minimal, safe recursive-descent parser for + - * / and parentheses. No eval(), no reflection. */
    private static final class SimpleExpressionParser {
        private final String s;
        private int pos;
        SimpleExpressionParser(String s) { this.s = s.replaceAll("\\s+", ""); }

        double parse() {
            double v = parseExpr();
            if (pos != s.length()) throw new IllegalArgumentException("Unexpected trailing input");
            return v;
        }
        private double parseExpr() {
            double v = parseTerm();
            while (pos < s.length() && (s.charAt(pos) == '+' || s.charAt(pos) == '-')) {
                char op = s.charAt(pos++);
                double rhs = parseTerm();
                v = op == '+' ? v + rhs : v - rhs;
            }
            return v;
        }
        private double parseTerm() {
            double v = parseFactor();
            while (pos < s.length() && (s.charAt(pos) == '*' || s.charAt(pos) == '/')) {
                char op = s.charAt(pos++);
                double rhs = parseFactor();
                v = op == '*' ? v * rhs : v / rhs;
            }
            return v;
        }
        private double parseFactor() {
            if (pos < s.length() && s.charAt(pos) == '-') { pos++; return -parseFactor(); }
            if (pos < s.length() && s.charAt(pos) == '(') {
                pos++;
                double v = parseExpr();
                if (pos >= s.length() || s.charAt(pos) != ')') throw new IllegalArgumentException("Missing )");
                pos++;
                return v;
            }
            int start = pos;
            while (pos < s.length() && (Character.isDigit(s.charAt(pos)) || s.charAt(pos) == '.')) pos++;
            if (start == pos) throw new IllegalArgumentException("Expected number at " + pos);
            return Double.parseDouble(s.substring(start, pos));
        }
    }

    // ------------------------------------------------------------ Time parsing --

    /** Parses phrases like "7", "7:30", "7 pm", "7:30 am" into {hour24, minute}. */
    private static int[] extractTime(String q) {
        Matcher m = Pattern.compile("(?:at\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").matcher(q);
        while (m.find()) {
            try {
                int hour = Integer.parseInt(m.group(1));
                int minute = m.group(2) != null ? Integer.parseInt(m.group(2)) : 0;
                String ampm = m.group(3);
                if (hour > 23 || minute > 59) continue;
                if (ampm != null) {
                    if (ampm.equalsIgnoreCase("pm") && hour < 12) hour += 12;
                    if (ampm.equalsIgnoreCase("am") && hour == 12) hour = 0;
                }
                return new int[]{hour, minute};
            } catch (NumberFormatException ignored) {}
        }
        return null;
    }

    /** Parses durations like "10 minutes", "1 hour and 30 minutes", "45 seconds". */
    private static int extractDurationSeconds(String q) {
        int total = 0;
        Matcher m = Pattern.compile("(\\d+)\\s*(hour|hr|minute|min|second|sec)s?").matcher(q);
        while (m.find()) {
            int val = Integer.parseInt(m.group(1));
            String unit = m.group(2);
            if (unit.startsWith("hour") || unit.startsWith("hr")) total += val * 3600;
            else if (unit.startsWith("min")) total += val * 60;
            else total += val;
        }
        return total;
    }

    private static String describeDuration(int seconds) {
        int h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append(h == 1 ? " hour " : " hours ");
        if (m > 0) sb.append(m).append(m == 1 ? " minute " : " minutes ");
        if (s > 0 && h == 0) sb.append(s).append(s == 1 ? " second" : " seconds");
        return sb.toString().trim();
    }

    // ------------------------------------------------------------- Utilities ---

    private static boolean safeToLaunch(Context ctx, Intent i) {
        return i.resolveActivity(ctx.getPackageManager()) != null;
    }

    private static int batteryPercent(Context ctx) {
        try {
            BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            if (bm == null) return -1;
            return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        } catch (Exception e) {
            return -1;
        }
    }

    private static boolean setFlashlight(Context ctx, boolean on) {
        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return false;
            String[] ids = cm.getCameraIdList();
            if (ids.length == 0) return false;
            cm.setTorchMode(ids[0], on);
            return true;
        } catch (CameraAccessException | RuntimeException e) {
            return false;
        }
    }

    private static void adjustVolume(Context ctx, int direction) {
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
        } catch (Exception ignored) {}
    }
}

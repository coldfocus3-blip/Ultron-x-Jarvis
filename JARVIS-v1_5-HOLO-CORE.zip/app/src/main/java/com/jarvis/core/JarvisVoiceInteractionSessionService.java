package com.jarvis.core;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;
import android.service.voice.VoiceInteractionSessionService;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.WindowManager;

import java.util.Locale;

/**
 * Cinematic assistant surface shown by Android when JARVIS is invoked.
 * It deliberately stays lightweight because Android owns the voice-session lifecycle.
 */
public class JarvisVoiceInteractionSessionService extends VoiceInteractionSessionService {
    @Override public VoiceInteractionSession onNewSession(Bundle args) {
        return new JarvisSession(this);
    }

    private static class JarvisSession extends VoiceInteractionSession {
        JarvisSession(android.content.Context context) { super(context); setKeepAwake(true); }

        @Override public View onCreateContentView() { return new SessionHud(getContext()); }

        @Override public void onShow(Bundle args, int showFlags) {
            super.onShow(args, showFlags);
            try {
                getWindow().getWindow().addFlags(
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            } catch (Exception ignored) {}
        }
    }

    private static class SessionHud extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        private final ScaleGestureDetector scale;
        private float yaw = 0f, pitch = 0f, zoom = 1f, lastX, lastY;
        private long frame = 0;

        SessionHud(android.content.Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) {
                    zoom = Math.max(.65f, Math.min(1.8f, zoom * d.getScaleFactor())); invalidate(); return true;
                }
            });
        }

        @Override protected void onDraw(Canvas c) {
            int w=getWidth(), h=getHeight(); frame++;
            int blue=Color.rgb(30,210,255);
            c.drawColor(Color.rgb(1,5,9));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.argb(24,80,170,210));
            float grid=Math.max(42, Math.min(w,h)/11f);
            for(float x=0;x<w;x+=grid)c.drawLine(x,0,x,h,p);
            for(float y=0;y<h;y+=grid)c.drawLine(0,y,w,y,p);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(20,30,210,255)); c.drawCircle(w/2f,h*.52f,Math.min(w,h)*.31f*zoom,p);
            float base=Math.min(w,h)*.13f*zoom;
            float cx=w/2f, cy=h*.52f;
            float depth=.82f+.18f*(float)Math.cos(Math.toRadians(yaw));

            p.setStyle(Paint.Style.STROKE);
            for(int i=0;i<8;i++){
                float rx=base*(1.0f+i*.18f)*depth;
                float ry=base*(.40f+i*.06f);
                float drift=frame*(.5f+i*.04f)+yaw*1.3f+i*27;
                p.setStrokeWidth(1.2f); p.setColor(Color.argb(35+i*5,30,210,255));
                r.set(cx-rx,cy-ry,cx+rx,cy+ry); c.drawArc(r,drift,190,false,p); c.drawArc(r,drift+215,100,false,p);
            }
            p.setStrokeWidth(2); p.setColor(Color.argb(95,30,210,255));
            r.set(cx-base*1.5f,cy-base*1.5f,cx+base*1.5f,cy+base*1.5f); c.drawArc(r,yaw+frame*.6f,240,false,p);
            p.setStyle(Paint.Style.FILL); p.setColor(blue); p.setShadowLayer(30,0,0,Color.argb(160,30,210,255)); c.drawCircle(cx,cy,base*.58f,p); p.clearShadowLayer();
            p.setColor(Color.rgb(2,12,17)); c.drawCircle(cx,cy,base*.42f,p);
            text(c,"JARVIS",cx,cy+5,15,blue,true,Paint.Align.CENTER);
            text(c,"VOICE LINK ACTIVE",cx,cy+base*2.15f,10,Color.rgb(170,205,215),false,Paint.Align.CENTER);
            text(c,String.format(Locale.US,"YAW %03d°  TILT %03d°  ZOOM %.1fx",Math.round(yaw),Math.round(pitch),zoom),cx,cy+base*2.48f,8,Color.rgb(90,130,145),false,Paint.Align.CENTER);
            text(c,"LISTENING FOR COMMAND",cx,cy+base*2.88f,9,blue,true,Paint.Align.CENTER);
            text(c,"JARVIS",32,42,20,blue,true,Paint.Align.LEFT);
            text(c,"SECURE VOICE INTERFACE",32,62,9,Color.rgb(100,135,150),false,Paint.Align.LEFT);
            postInvalidateDelayed(32);
        }
        private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align a){
            p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTextAlign(a);p.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE,bold?1:0));c.drawText(s,x,y,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            scale.onTouchEvent(e);
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();return true;}
            if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&e.getPointerCount()==1){float dx=e.getX()-lastX,dy=e.getY()-lastY;yaw=(yaw+dx*.4f)%360f;pitch=Math.max(-55,Math.min(55,pitch-dy*.25f));lastX=e.getX();lastY=e.getY();invalidate();return true;}
            return true;
        }
    }
}

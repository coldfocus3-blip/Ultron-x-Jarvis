package com.jarvis.core;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionService;
import android.util.Log;

/**
 * Global Android assistant entry point. Android keeps the selected
 * VoiceInteractionService alive so it can participate in assistant/hotword
 * interactions, including keyguard/locked-screen invocation.
 */
public class JarvisVoiceInteractionService extends VoiceInteractionService {
    private static final String TAG = "JARVIS";
    private static JarvisVoiceInteractionService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Log.i(TAG, "JARVIS global voice service created");
    }

    @Override
    public void onReady() {
        super.onReady();
        Log.i(TAG, "JARVIS global voice service ready");

        // The user explicitly enables the always-listening mode from the app.
        // Once permission has already been granted, the selected global assistant
        // can restart its microphone service when Android brings this service back.
        if (getSharedPreferences("jarvis", MODE_PRIVATE)
                .getBoolean("always_listening", false)
                && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try {
                startForegroundService(new Intent(this, JarvisAlwaysListeningService.class));
            } catch (Exception e) {
                Log.w(TAG, "Could not restart always-listening service", e);
            }
        }
    }

    public static void triggerWake(Context context, String heard) {
        if (instance != null) {
            Bundle args = new Bundle();
            args.putString("jarvis_wake_text", heard == null ? "" : heard);
            try {
                instance.showSession(args, 0);
                Log.i(TAG, "JARVIS session shown after wake phrase");
            } catch (Exception e) {
                Log.w(TAG, "Could not show voice session", e);
            }
        } else {
            Log.w(TAG, "VoiceInteractionService is not active; JARVIS must be selected as system assistant");
        }
    }

    @Override
    public void onLaunchVoiceAssistFromKeyguard() {
        Bundle args = new Bundle();
        args.putBoolean("from_keyguard", true);
        showSession(args, 0);
    }

    @Override
    public void onShutdown() {
        Log.i(TAG, "JARVIS global voice service shutting down");
        instance = null;
        super.onShutdown();
    }
}

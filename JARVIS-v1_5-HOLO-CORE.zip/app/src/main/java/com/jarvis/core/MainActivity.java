package com.jarvis.core;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.app.role.RoleManager;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.provider.Settings;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private JarvisHudView hud;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private final Handler handler = new Handler();
    private static final int MIC_REQUEST = 42;
    private static final int NOTIFICATION_REQUEST = 43;
    private static final int ASSISTANT_ROLE_REQUEST = 44;

    private boolean isAssistantRoleHeld() {
        if (android.os.Build.VERSION.SDK_INT < 29) return true;
        RoleManager roleManager = (RoleManager) getSystemService(Context.ROLE_SERVICE);
        return roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)
                && roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT);
    }

    private void requestAssistantRole() {
        if (android.os.Build.VERSION.SDK_INT < 29) {
            hud.setStatus("SYSTEM ASSISTANT ROLE NOT AVAILABLE");
            return;
        }
        RoleManager roleManager = (RoleManager) getSystemService(Context.ROLE_SERVICE);
        if (roleManager == null || !roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
            hud.setStatus("ASSISTANT ROLE NOT AVAILABLE");
            hud.setResponse("This tablet does not expose Android's assistant role to third-party apps.");
            return;
        }
        if (roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)) {
            hud.setStatus("JARVIS IS THE SYSTEM ASSISTANT");
            return;
        }
        try {
            startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT), ASSISTANT_ROLE_REQUEST);
        } catch (Exception e) {
            hud.setStatus("OPENING ASSISTANT SETTINGS");
            try { startActivity(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)); } catch (Exception ignored) {}
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        } else {
            enableAlwaysListeningAfterSetup();
        }
    }

    private void enableAlwaysListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            hud.setStatus("MICROPHONE ACCESS REQUIRED");
            return;
        }

        if (!isAssistantRoleHeld()) {
            hud.setStatus("SYSTEM ASSISTANT SETUP REQUIRED");
            hud.setResponse("Set JARVIS as the tablet's Digital Assistant first. That is the Android-supported path for lock-screen assistant behavior.");
            requestAssistantRole();
            return;
        }
        requestNotificationPermissionIfNeeded();
    }

    private void enableAlwaysListeningAfterSetup() {
        getSharedPreferences("jarvis", MODE_PRIVATE)
                .edit().putBoolean("always_listening", true).apply();

        try {
            startForegroundService(new Intent(this, JarvisAlwaysListeningService.class));
            hud.setStatus("ALWAYS-ON VOICE LINK ACTIVE");
            hud.setResponse("JARVIS is listening for the wake phrase: \"Hey Jarvis\".\nAndroid will show an ongoing microphone notification while this mode is active.");
        } catch (Exception e) {
            hud.setStatus("VOICE LINK COULD NOT START");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        hideSystemBars();

        hud = new JarvisHudView();
        setContentView(hud);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS && tts != null) {
                JarvisVoiceEngine.configure(tts);
            }
        });

        // First launch: ask for the microphone while JARVIS is visible. After
        // approval, the user-enabled always-on voice link is started.
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            handler.postDelayed(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST), 700);
        } else if (getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("always_listening", false)) {
            handler.postDelayed(this::enableAlwaysListening, 300);
        }
    }

    private void hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            hud.setStatus("MICROPHONE ACCESS REQUIRED");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this device.");
            return;
        }

        if (recognizer != null) recognizer.destroy();
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
        } catch (Exception e) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        }

        recognizer.setRecognitionListener(new SimpleRecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                hud.setStatus("LISTENING • SPEAK NOW");
                hud.setListening(true);
            }
            @Override public void onBeginningOfSpeech() {
                hud.setStatus("LISTENING • RECEIVING");
                hud.setListening(true);
            }
            @Override public void onEndOfSpeech() {
                hud.setStatus("PROCESSING");
                hud.setListening(false);
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (r == null || r.isEmpty()) ? "" : r.get(0);
                handle(text);
            }
            @Override public void onError(int error) {
                hud.setListening(false);
                if (error == SpeechRecognizer.ERROR_NO_MATCH) {
                    hud.setStatus("READY • NO SPEECH DETECTED");
                } else {
                    hud.setStatus("READY");
                }
            }
        });

        hud.setStatus("INITIALIZING VOICE LINK");
        hud.setListening(true);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        recognizer.startListening(i);
    }

    private void handle(String raw) {
        if (raw == null) raw = "";
        hud.setLastCommand(raw);

        if (raw.trim().isEmpty()) {
            hud.setStatus("READY");
            return;
        }

        JarvisBrain.Result result = JarvisBrain.process(this, raw);
        say(result.speech);
        if (result.intent != null) {
            handler.postDelayed(() -> {
                try {
                    startActivity(result.intent);
                } catch (Exception e) {
                    hud.setResponse("I could not complete that action: " + e.getMessage());
                }
            }, 500);
        }
    }

    private void say(String text) {
        hud.setResponse(text);
        hud.setStatus("JARVIS • SPEAKING");
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_response");
        handler.postDelayed(() -> hud.setStatus("READY • SYSTEM NOMINAL"), 1800);
    }

    private void showPermissions() {
        boolean active = getSharedPreferences("jarvis", MODE_PRIVATE)
                .getBoolean("always_listening", false);
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean assistant = isAssistantRoleHeld();
        String battery = "UNKNOWN";
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            battery = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()) ? "UNRESTRICTED" : "OPTIMIZED";
        }
        new AlertDialog.Builder(this)
                .setTitle("JARVIS • SYSTEM LINK")
                .setMessage(
                        "MICROPHONE: " + (mic ? "GRANTED" : "NOT GRANTED")
                        + "\nSYSTEM ASSISTANT: " + (assistant ? "JARVIS" : "NOT JARVIS")
                        + "\nALWAYS-ON LINK: " + (active ? "ACTIVE" : "OFF")
                        + "\nBATTERY POLICY: " + battery
                        + "\n\nFor reliable lock-screen behavior, JARVIS should be the tablet's selected assistant. Android keeps the selected VoiceInteractionService alive for background assistant/hotword support; the microphone itself still requires an explicit RECORD_AUDIO grant and an ongoing microphone foreground-service notification.")
                .setNeutralButton("SET ASSISTANT", (d, w) -> requestAssistantRole())
                .setNegativeButton(active ? "TURN OFF" : "CLOSE", (d, w) -> {
                    if (active) {
                        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putBoolean("always_listening", false).apply();
                        stopService(new Intent(this, JarvisAlwaysListeningService.class));
                        hud.setStatus("ALWAYS-ON VOICE LINK OFF");
                    }
                })
                .setPositiveButton(active ? "KEEP ACTIVE" : "ENABLE", (d, w) -> enableAlwaysListening())
                .show();
    }

    private void toggleTheme() {
        hud.toggleGold();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableAlwaysListening();
            } else {
                hud.setStatus("MICROPHONE DENIED • READY");
                hud.setResponse("Microphone access was not granted. JARVIS cannot hear the wake phrase without Android microphone permission.");
            }
        } else if (requestCode == NOTIFICATION_REQUEST) {
            enableAlwaysListeningAfterSetup();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ASSISTANT_ROLE_REQUEST) {
            if (resultCode == RESULT_OK) {
                hud.setStatus("JARVIS IS THE SYSTEM ASSISTANT");
                hud.setResponse("System assistant link established. Always-on voice can now use Android's assistant lifecycle.");
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    requestNotificationPermissionIfNeeded();
                }
            } else {
                hud.setStatus("ASSISTANT ROLE NOT GRANTED");
                hud.setResponse("JARVIS can still work from the app, but lock-screen/global assistant behavior requires you to select JARVIS as the system assistant.");
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    private class JarvisHudView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF rect = new RectF();
        private boolean gold = false;
        private boolean listening = false;
        private long frame = 0;
        private String status = "READY • SYSTEM NOMINAL";
        private String response = "Good evening. JARVIS core is online.\nTap the reactor to speak.";
        private String lastCommand = "No command received";
        private float yaw = 0f;
        private float pitch = 0f;
        private float zoom = 1f;
        private float downX, downY;
        private boolean dragging = false;
        private final ScaleGestureDetector scaleDetector;

        JarvisHudView() {
            super(MainActivity.this);
            p.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.NORMAL));
            setFocusable(true);
            setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            setContentDescription("JARVIS reactor. Double tap to speak a command.");
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            scaleDetector = new ScaleGestureDetector(MainActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    zoom *= detector.getScaleFactor();
                    zoom = Math.max(0.62f, Math.min(1.85f, zoom));
                    invalidate();
                    return true;
                }
            });
        }

        void setStatus(String s) { status = s; invalidate(); }
        void setResponse(String s) {
            response = s;
            setContentDescription("JARVIS says: " + s);
            announceForAccessibility(s);
            invalidate();
        }
        void setLastCommand(String s) { lastCommand = s; invalidate(); }
        void setListening(boolean b) {
            listening = b;
            if (b) announceForAccessibility("Listening. Speak your command.");
            invalidate();
        }
        void toggleGold() {
            gold = !gold;
            announceForAccessibility(gold ? "Ultron gold theme" : "Jarvis blue theme");
            invalidate();
        }

        private int accent() { return Color.rgb(gold ? 255 : 30, gold ? 177 : 210, gold ? 55 : 255); }
        private int accentDim() { return Color.argb(110, Color.red(accent()), Color.green(accent()), Color.blue(accent())); }
        private int accentSoft() { return Color.argb(45, Color.red(accent()), Color.green(accent()), Color.blue(accent())); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w = getWidth(), h = getHeight();
            c.drawColor(Color.rgb(2, 6, 10));
            frame++;

            // Subtle grid / scan field
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1f);
            p.setColor(Color.argb(22, 120, 180, 210));
            float grid = Math.max(42f, Math.min(w, h) / 12f);
            for (float x = 0; x < w; x += grid) c.drawLine(x, 0, x, h, p);
            for (float y = 0; y < h; y += grid) c.drawLine(0, y, w, y, p);

            // Header
            drawText(c, "J A R V I S", 42, 46, 20, accent(), Paint.Align.LEFT, true);
            drawText(c, gold ? "ULTRON PROTOCOL" : "STARK // VOICE INTERFACE", 44, 70, 11, Color.rgb(120, 145, 160), Paint.Align.LEFT, false);
            drawText(c, "● SECURE", w - 42, 48, 11, accent(), Paint.Align.RIGHT, true);
            drawText(c, "LOCAL CORE", w - 42, 68, 10, Color.rgb(120,145,160), Paint.Align.RIGHT, false);

            // Side telemetry panels
            float panelY = h * 0.23f;
            drawPanel(c, 34, panelY, 245, panelY + 118, "CORE TELEMETRY");
            drawText(c, "VOICE LINK", 52, panelY + 49, 10, Color.rgb(125,150,165), Paint.Align.LEFT, false);
            drawText(c, listening ? "ACTIVE" : "STANDBY", 52, panelY + 69, 14, accent(), Paint.Align.LEFT, true);
            drawText(c, "PRIVACY", 52, panelY + 93, 10, Color.rgb(125,150,165), Paint.Align.LEFT, false);
            drawText(c, "FIREWALL ON", 52, panelY + 110, 11, accent(), Paint.Align.LEFT, true);

            drawPanel(c, w - 245, panelY, w - 34, panelY + 118, "SYSTEM STATUS");
            drawText(c, "CORE", w - 228, panelY + 49, 10, Color.rgb(125,150,165), Paint.Align.LEFT, false);
            drawText(c, "ONLINE", w - 228, panelY + 69, 14, accent(), Paint.Align.LEFT, true);
            drawText(c, "MODE", w - 228, panelY + 93, 10, Color.rgb(125,150,165), Paint.Align.LEFT, false);
            drawText(c, gold ? "GOLD / ULTRON" : "BLUE / JARVIS", w - 228, panelY + 110, 11, accent(), Paint.Align.LEFT, true);

            // Central holographic plasma core. Drag horizontally for 360° yaw,
            // vertically for tilt; pinch to zoom. The layered projection gives
            // depth without pretending this is a full 3-D renderer.
            float cx = w / 2f;
            float cy = h * 0.52f;
            float base = Math.min(w, h) * 0.135f * zoom;
            float pulse = (float)(Math.sin(frame * 0.075) * 4 + Math.sin(frame * 0.021) * 2);
            if (listening) pulse += (float)(Math.sin(frame * 0.23) * 7);
            float yawRad = (float)Math.toRadians(yaw);
            float pitchRad = (float)Math.toRadians(pitch);
            float depth = 0.82f + 0.18f * (float)Math.cos(yawRad);

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(22, Color.red(accent()), Color.green(accent()), Color.blue(accent())));
            c.drawCircle(cx, cy, base * 2.25f + pulse, p);
            p.setColor(Color.argb(12, Color.red(accent()), Color.green(accent()), Color.blue(accent())));
            c.drawCircle(cx, cy, base * 3.0f, p);

            // Fine plasma filaments: restrained, flowing around the core.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.3f);
            for (int ring = 0; ring < 7; ring++) {
                float rx = base * (1.15f + ring * 0.19f) * depth;
                float ry = base * (0.45f + ring * 0.055f) * (0.90f + 0.10f * (float)Math.cos(pitchRad));
                float drift = frame * (0.55f + ring * 0.045f) + yaw * 1.4f + ring * 31f;
                p.setColor(Color.argb(42 + ring * 6, Color.red(accent()), Color.green(accent()), Color.blue(accent())));
                rect.set(cx-rx, cy-ry, cx+rx, cy+ry);
                c.drawArc(rect, drift, 205, false, p);
                c.drawArc(rect, drift+215, 105, false, p);
            }

            // Rotating translucent meridian planes make the object feel spatial.
            p.setStrokeWidth(2f);
            for (int i=0; i<3; i++) {
                float a = (float)Math.toRadians(yaw + frame*0.28f + i*60f);
                float sx = Math.abs((float)Math.cos(a));
                float sy = 0.38f + 0.12f*(float)Math.abs(Math.sin(a+pitchRad));
                p.setColor(Color.argb(65, Color.red(accent()), Color.green(accent()), Color.blue(accent())));
                rect.set(cx-base*1.55f*sx, cy-base*1.55f*sy, cx+base*1.55f*sx, cy+base*1.55f*sy);
                c.drawOval(rect, p);
            }

            p.setColor(accentDim());
            p.setStrokeWidth(2.2f);
            rect.set(cx-base*1.5f, cy-base*1.5f, cx+base*1.5f, cy+base*1.5f);
            c.drawArc(rect, yaw+frame*0.6f, 230, false, p);
            rect.set(cx-base*1.82f, cy-base*1.82f, cx+base*1.82f, cy+base*1.82f);
            c.drawArc(rect, 190-yaw-frame*0.4f, 105, false, p);

            p.setStyle(Paint.Style.FILL);
            p.setShadowLayer(30,0,0,accentDim());
            p.setColor(accent());
            c.drawCircle(cx, cy, base*0.60f + pulse*0.12f, p);
            p.clearShadowLayer();
            p.setColor(Color.rgb(3,12,17));
            c.drawCircle(cx, cy, base*0.43f, p);
            drawText(c, listening ? "LISTEN" : "JARVIS", cx, cy+5, 14, accent(), Paint.Align.CENTER, true);

            // Tiny spatial readout.
            drawText(c, String.format(Locale.US, "YAW %03d°  TILT %03d°  ZOOM %.1fx", Math.round(yaw), Math.round(pitch), zoom),
                    cx, cy + base*2.45f, 8, Color.rgb(105,135,150), Paint.Align.CENTER, false);

            // Bottom command panel
            float by = h - 205;
            drawPanel(c, 34, by, w - 34, h - 82, "NEURAL RESPONSE");
            drawText(c, status, 55, by + 43, 11, accent(), Paint.Align.LEFT, true);
            drawWrapped(c, response, 55, by + 72, w - 110, 14, Color.rgb(215,225,230), 20);

            // Last command micro-line
            String lc = lastCommand.length() > 58 ? lastCommand.substring(0,58) + "…" : lastCommand;
            drawText(c, "LAST INPUT  //  " + lc, 55, h - 101, 9, Color.rgb(105,130,145), Paint.Align.LEFT, false);

            // Bottom controls
            float gap = 10f;
            float left = 34f;
            float right = w - 34f;
            float box = (right - left - gap * 2f) / 3f;
            drawControl(c, left, h-65, left+box, h-22, "THEME", gold ? "GOLD" : "BLUE");
            drawControl(c, left+box+gap, h-65, left+box*2+gap, h-22, "ASSISTANT", isAssistantRoleHeld() ? "JARVIS" : "SETUP");
            drawControl(c, left+box*2+gap*2, h-65, right, h-22, "SECURITY", "VOICE");
            drawText(c, "TAP REACTOR TO SPEAK", cx, h-84, 9, Color.rgb(110,135,150), Paint.Align.CENTER, false);

            // Corner brackets
            drawCorners(c, 18, 18, w-18, h-18);
            postInvalidateDelayed(32);
        }

        private void drawPanel(Canvas c, float l, float t, float r, float b, String title) {
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(120, 4, 13, 19)); c.drawRect(l,t,r,b,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(Color.argb(85, Color.red(accent()),Color.green(accent()),Color.blue(accent()))); c.drawRect(l,t,r,b,p);
            drawText(c, title, l+18, t+22, 9, Color.rgb(115,145,160), Paint.Align.LEFT, true);
            p.setColor(accentDim()); p.setStrokeWidth(2f); c.drawLine(l+18,t+29,l+75,t+29,p);
        }

        private void drawControl(Canvas c, float l, float t, float r, float b, String top, String bottom) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(Color.argb(90, Color.red(accent()),Color.green(accent()),Color.blue(accent()))); c.drawRect(l,t,r,b,p);
            drawText(c, top, (l+r)/2, t+15, 8, Color.rgb(100,125,140), Paint.Align.CENTER, false);
            drawText(c, bottom, (l+r)/2, t+31, 10, accent(), Paint.Align.CENTER, true);
        }

        private void drawCorners(Canvas c, float l, float t, float r, float b) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2f); p.setColor(Color.argb(90,Color.red(accent()),Color.green(accent()),Color.blue(accent())));
            float s=18;
            c.drawLine(l,t,l+s,t,p); c.drawLine(l,t,l,t+s,p);
            c.drawLine(r,t,r-s,t,p); c.drawLine(r,t,r,t+s,p);
            c.drawLine(l,b,l+s,b,p); c.drawLine(l,b,l,b-s,p);
            c.drawLine(r,b,r-s,b,p); c.drawLine(r,b,r,b-s,p);
        }

        private void drawText(Canvas c, String s, float x, float y, float size, int color, Paint.Align align, boolean bold) {
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTextAlign(align);
            p.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL));
            c.drawText(s, x, y, p);
        }

        private void drawWrapped(Canvas c, String s, float x, float y, float maxWidth, float size, int color, float lineGap) {
            p.setTextSize(size); p.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.NORMAL));
            String[] words=s.split(" "); String line=""; float yy=y;
            for(String word:words){ String test=line.isEmpty()?word:line+" "+word; if(p.measureText(test)>maxWidth && !line.isEmpty()){drawText(c,line,x,yy,size,color,Paint.Align.LEFT,false); yy+=lineGap; line=word;} else line=test; }
            if(!line.isEmpty()) drawText(c,line,x,yy,size,color,Paint.Align.LEFT,false);
        }

        @Override public boolean performClick() {
            super.performClick();
            startListening();
            return true;
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            scaleDetector.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX(); downY = e.getY(); dragging = false; return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (e.getPointerCount() == 1) {
                        float dx = e.getX() - downX;
                        float dy = e.getY() - downY;
                        if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragging = true;
                        yaw += dx * 0.42f;
                        pitch -= dy * 0.28f;
                        while (yaw >= 360f) yaw -= 360f;
                        while (yaw < 0f) yaw += 360f;
                        pitch = Math.max(-55f, Math.min(55f, pitch));
                        downX = e.getX(); downY = e.getY(); invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    float x=e.getX(), y=e.getY(); int w=getWidth(), h=getHeight();
                    if (!dragging && e.getPointerCount() == 1) {
                        float cx=w/2f, cy=h*0.52f;
                        if (Math.hypot(x-cx,y-cy) < Math.min(w,h)*0.24) { performClick(); return true; }
                        if (y>h-80) {
                            float gap=10f, left=34f, right=w-34f, box=(right-left-gap*2f)/3f;
                            if (x < left+box) { toggleGold(); return true; }
                            if (x < left+box*2f+gap) { requestAssistantRole(); return true; }
                            showPermissions(); return true;
                        }
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
                default:
                    return true;
            }
        }
    }
}

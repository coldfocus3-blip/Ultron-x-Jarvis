package com.jarvis.core;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

/**
 * User-enabled always-listening layer for JARVIS.
 *
 * Android does not provide an "all time" runtime microphone permission. Instead,
 * after the user grants RECORD_AUDIO while JARVIS is visible, this foreground
 * microphone service keeps a low-level speech recognition loop alive. When the
 * recognition engine hears "Hey Jarvis", "Hello Jarvis", or "Jarvis", it wakes
 * the selected VoiceInteractionService and the assistant session UI.
 *
 * Recognition is requested offline when the device/provider supports it. The
 * actual availability and background behavior remain subject to Android and OEM
 * policy.
 */
public class JarvisAlwaysListeningService extends Service {
    private static final String TAG = "JARVIS_ALWAYS";
    private static final String CHANNEL_ID = "jarvis_voice_link";
    private static final int NOTIFICATION_ID = 701;

    public static final String ACTION_ENABLE = "com.jarvis.core.ENABLE_ALWAYS_LISTENING";
    public static final String ACTION_DISABLE = "com.jarvis.core.DISABLE_ALWAYS_LISTENING";

    private final Handler handler = new Handler();
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean restarting;
    private boolean awaitingCommand;
    private boolean speaking;
    private long lastWakeMs;

    private final Runnable restartRunnable = new Runnable() {
        @Override public void run() {
            restarting = false;
            startRecognitionLoop();
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startAsForeground();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                JarvisVoiceEngine.configure(tts);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { speaking = true; }
                    @Override public void onDone(String utteranceId) {
                        speaking = false;
                        scheduleRestart(180);
                    }
                    @Override public void onError(String utteranceId) {
                        speaking = false;
                        scheduleRestart(180);
                    }
                });
            }
        });
        startRecognitionLoop();
        Log.i(TAG, "Always-listening voice link started");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_DISABLE.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 33) {
            updateNotification("ALWAYS-ON • SAY \"HEY JARVIS\"");
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 701, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS voice link active")
                .setContentText("Listening locally for the JARVIS wake phrase")
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .setShowWhen(false);

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                    NOTIFICATION_ID,
                    builder.build(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIFICATION_ID, builder.build());
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "JARVIS Voice Link",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Ongoing microphone access for the user-enabled JARVIS wake phrase");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void updateNotification(String text) {
        Intent launch = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 702, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("JARVIS voice link active")
                .setContentText(text)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .setShowWhen(false)
                .build();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, notification);
    }

    private void startRecognitionLoop() {
        if (restarting || speaking || !hasMicPermission()) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "Speech recognition is unavailable");
            updateNotification("VOICE ENGINE UNAVAILABLE");
            return;
        }

        destroyRecognizer();
        try {
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
                updateNotification("ON-DEVICE • SAY \"HEY JARVIS\"");
            } else {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this);
                updateNotification("VOICE LINK • SAY \"HEY JARVIS\"");
            }
        } catch (Exception e) {
            Log.e(TAG, "Could not create speech recognizer", e);
            scheduleRestart(2000);
            return;
        }

        recognizer.setRecognitionListener(new SimpleRecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                updateNotification("LISTENING • SAY \"HEY JARVIS\"");
            }

            @Override public void onResults(Bundle results) {
                ArrayList<String> values = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = values == null || values.isEmpty() ? "" : values.get(0);
                processSpeech(text);
                scheduleRestart(250);
            }

            @Override public void onError(int error) {
                if (speaking) return;
                // SpeechRecognizer sessions are intentionally short-lived. Restarting
                // them is what gives this service its continuous-listening behavior.
                scheduleRestart(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200 : 450);
            }
        });

        Intent input = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

        try {
            recognizer.startListening(input);
        } catch (Exception e) {
            Log.e(TAG, "startListening failed", e);
            scheduleRestart(1500);
        }
    }

    private void processSpeech(String raw) {
        if (raw == null) raw = "";
        String q = raw.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return;

        boolean wake = q.contains("hey jarvis")
                || q.contains("hello jarvis")
                || q.equals("jarvis")
                || q.startsWith("jarvis ");

        if (wake) {
            destroyRecognizer();
            long now = System.currentTimeMillis();
            if (now - lastWakeMs < 1800) return;
            lastWakeMs = now;
            awaitingCommand = true;
            JarvisVoiceInteractionService.triggerWake(this, raw);

            String remainder = q.replaceFirst("^(hey|hello)?\\s*jarvis[,:]?\\s*", "").trim();
            if (remainder.isEmpty()) {
                speak("Yes? I'm listening.");
            } else {
                awaitingCommand = false;
                handleCommand(remainder);
            }
            return;
        }

        if (awaitingCommand) {
            awaitingCommand = false;
            handleCommand(q);
        }
    }

    private void handleCommand(String q) {
        if (q.contains("time")) {
            String time = new java.text.SimpleDateFormat("h:mm a", Locale.getDefault())
                    .format(new java.util.Date());
            speak("The current time is " + time + ".");
        } else if (q.contains("hello") || q.contains("hi")) {
            speak("Good to hear you. JARVIS is online.");
        } else {
            speak("I heard you. The voice link is active, but the full reasoning engine is not connected yet.");
        }
    }

    private void speak(String text) {
        destroyRecognizer();
        speaking = true;
        updateNotification("JARVIS • SPEAKING");
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_always_on");
        } else {
            speaking = false;
            scheduleRestart(250);
        }
    }

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void scheduleRestart(long delay) {
        if (restarting || !hasMicPermission()) return;
        restarting = true;
        handler.removeCallbacks(restartRunnable);
        handler.postDelayed(restartRunnable, delay);
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
            tts.shutdown();
            tts = null;
        }
        Log.i(TAG, "Always-listening voice link stopped");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

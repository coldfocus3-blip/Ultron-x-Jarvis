# JARVIS v1.4 — HOLO CORE

A tablet-first Android JARVIS foundation with a cinematic, interactive holographic core.

## Visual controls
- Drag one finger across the reactor to rotate its holographic projection through a full 360°.
- Drag vertically to tilt the projection.
- Pinch with two fingers to zoom from 0.65x to 1.8x.
- Tap the reactor to start voice recognition.
- Theme toggles between JARVIS blue and ULTRON gold.

## Voice architecture
- Android VoiceInteractionService is the global assistant entry point.
- Android keeps the selected VoiceInteractionService running for assistant/hotword support.
- The assistant session is shown by the system when the assistant is invoked.
- A user-enabled microphone foreground service provides a fallback wake-phrase loop where the device permits it.
- On-device SpeechRecognizer is preferred when available.
- JARVIS stops recognition while speaking to avoid hearing its own TTS output.

## Important Android limitation
A normal SpeechRecognizer is not a hardware hotword detector and Android documents that it is not intended for continuous recognition. True hands-free hotwording depends on the device/OEM VoiceInteractionService and hotword implementation. Selecting JARVIS as the system assistant is therefore required for the strongest supported background-assistant path.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`
Uses Java 17, Gradle 8.11.1, AGP 8.10.1, compileSdk 36.
